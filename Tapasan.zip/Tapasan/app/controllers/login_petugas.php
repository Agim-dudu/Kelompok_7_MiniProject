<?php 

class login_petugas extends Controller {
    public function index()
    {
        $data['judul'] = 'Home';
        // $data['nama'] = $this->model('User_model')->getUser();
        $this->view('login-petugas/index', $data);
    }

    // public function confirm(){
    //     $data['input'] = $this->model('login_petugas_model')->confirmlogin($_POST);
    //     $db['login'] = $this->model('login_petugas_model')->getAllLogin();
    //     var_dump($data['input']['username']);
    //     var_dump($db['login']['username']);

    //     if($data['input']['username'] == $db['login']['username']){
    //         $this->view('home-petugas/index', $data);
    //     }
    // }
    
}