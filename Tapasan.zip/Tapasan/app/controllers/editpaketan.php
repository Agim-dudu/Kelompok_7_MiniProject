<?php

class editpaketan extends Controller {
    public function index($id)
        {
            $data['judul'] = 'Home';
            $data['paketan']=$this->model('ha_model')->getPaketanById($id);
            $this->view('editpaket/index', $data);
        }
}
