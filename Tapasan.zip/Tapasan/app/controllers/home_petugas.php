<?php 

class home_petugas extends Controller {
    public function index()
    {
        $data['judul'] = 'Home';
        $data['pelaundry_biasa'] = $this->model('TampilDetailOrder_model')->getAllPelaundryBiasa();
        $data['detail_order'] = $this->model('TampilDetailOrder_model')->getAllPelaundryMember();
        $data['paketan'] = $this->model('TampilDetailOrder_model')->getAllPaketan();
        $data['pelaundry'] = $this->model('TampilDetailOrder_model')->getAllMember();
        $this->view('home-petugas/index', $data);
    }

    public function ubahstatuspelaundry_biasa($id){
        if($this->model('TampilDetailOrder_model')->ubahstatuspelaundry_biasa($id)>0){
            header('Location :'.BASEURL.'/home-petugas');
            exit;
        }
    }
    public function ubahstatusmember($id){
        if($this->model('TampilDetailOrder_model')->ubahstatusmember($id)>0){
            header('Location :'.BASEURL.'/home-petugas');
            exit;
        }
    }
    public function ubahstatus()
        {   
            if($this->model('TampilDetailOrder_model')->TampilDetailOrder_model($_POST)>0){
                header('Location :'. BASEURL .'/home-admin');
                exit;
            }
        }
}
