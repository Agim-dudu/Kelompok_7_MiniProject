<?php 

define('BASEURL', 'http://localhost/Tapasan/public');

// DB
define('DB_HOST', 'localhost:3307');
define('DB_USER', 'root');
define('DB_PASS', 'Agim100822');
define('DB_NAME', 'test');

?>