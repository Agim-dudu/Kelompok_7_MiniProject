<?php

    class ha_model {
        private $db;

        public function __construct()
        {
            $this->db = new Database;
        }

        public function getAllPaketan()
        {
            $this->db->query('SELECT * from paketan');
            return $this->db->resultSet();
        }

        public function getAllPetugas()
        {
            $this->db->query('SELECT * from petugas');
            return $this->db->resultSet();

        }
        public function getAllAkun()
        {
            $this->db->query('SELECT * from akun');
            return $this->db->resultSet();

        }
        public function hapusDataPaketan($id)
        {
            $query = "DELETE FROM paketan WHERE id = :id";
            
            $this->db->query($query);
            $this->db->bind('id', $id);
            $this->db->execute();

            return $this->db->rowCount();
        }
        public function hapusDataAkun($id)
        {
            $query = "DELETE FROM akun WHERE id = :id";
            
            $this->db->query($query);
            $this->db->bind('id', $id);
            $this->db->execute();

            return $this->db->rowCount();
        }
        public function hapusDataPetugas($id)
        {
            $query = "DELETE FROM petugas WHERE id = :id";
            
            $this->db->query($query);
            $this->db->bind('id', $id);
            $this->db->execute();

            return $this->db->rowCount();
        }

        public function getAkunById($id){
            $this->db->query('SELECT * FROM akun WHERE id = :id');
            $this->db->bind('id',$id);
            return $this->db->single();

        }
        public function getPetugasById($id){
            $this->db->query('SELECT * FROM petugas WHERE id = :id');
            $this->db->bind('id',$id);
            return $this->db->single();
        }

        public function getPaketanById($id){
            $this->db->query('SELECT * FROM paketan WHERE id = :id');
            $this->db->bind('id',$id);
            return $this->db->single();

        }




        // method insert
        public function tambahDataPetugas($data)
        {
            $query = "INSERT INTO petugas
                        VALUES
                    ( :id, :nama, :nomer)";
            
            $this->db->query($query);
            $this->db->bind('id', $data['id']);
            $this->db->bind('nama', $data['nama']);
            $this->db->bind('nomer', $data['nomer']);

            $this->db->execute();

            return $this->db->rowCount();
        }
        public function tambahDataPaket($data)
        {
            $query = "INSERT INTO paketan
                        VALUES
                    ( :id, :jenis_laundry, :harga)";
            
            $this->db->query($query);
            $this->db->bind('id', $data['id']);
            $this->db->bind('jenis_laundry', $data['jenis_laundry']);
            $this->db->bind('harga', $data['harga']);

            $this->db->execute();

            return 1;
        }
        public function tambahDataAkun($data)
        {
            $query = "INSERT INTO akun
                        VALUES
                    (null, :username, :password)";
            
            $this->db->query($query);
            $this->db->bind('username', $data['username']);
            $this->db->bind('password', $data['password']);

            $this->db->execute();
            return $this->db->rowCount();
        }


        public function ubahDataAkun($data)
        {
            $query = "UPDATE mahasiswa SET
                        username = :username,
                        password = :password
                    WHERE id = :id";
            
            $this->db->query($query);
            $this->db->bind('username', $data['username']);
            $this->db->bind('password', $data['password']);
            $this->db->bind('id', $data['id']);

            $this->db->execute();

            return $this->db->rowCount();
        }
        public function ubahDataPaketan($data)
        {
            $query = "UPDATE paketan SET
                        jenis_laundry = :jenis_laundry,
                        harga = :harga
                    WHERE id = :id";
            
            $this->db->query($query);
            $this->db->bind('jenis_laundry', $data['jenis_laundry']);
            $this->db->bind('harga', $data['harga']);
            $this->db->bind('id', $data['id']);

            $this->db->execute();

            return $this->db->rowCount();
        }
        public function ubahDataPetugas($data)
        {
            $query = "UPDATE petugas SET
                        nama = :nama,
                        nomer = :nomer
                    WHERE id = :id";
            
            $this->db->query($query);
            $this->db->bind('nama', $data['nama']);
            $this->db->bind('nomer', $data['nomer']);
            $this->db->bind('id', $data['id']);

            $this->db->execute();

            return $this->db->rowCount();
        }
        
        public function ubahDataselesai($data)
        {
            $query = "UPDATE detail_laundry SET
                        keterangan = 'Selesai',
                    WHERE id = :id";
            
            $this->db->query($query);
            $this->db->bind('id', $data['id']);

            $this->db->execute();

            return $this->db->rowCount();
        }
    }


?>