<?php 

class TampilDetailOrder_model {
    private $db;

    public function __construct()
    {
        $this->db = new Database;
    }

    public function getAllPelaundryBiasa()
    {
        $this->db->query('SELECT pelaundry_biasa.nama_pelaundry, pelaundry_biasa.nomer_pelaundry, paketan.jenis_laundry, pelaundry_biasa.deskripsi, paketan.harga, pelaundry_biasa.jumlah, pelaundry_biasa.keterangan from pelaundry_biasa
        join paketan ON (paketan.id = pelaundry_biasa.jenis_laundry);');
        return $this->db->resultSet();

    }
    public function getAllPelaundryMember()
    {
        $this->db->query('SELECT pelaundry.nama,pelaundry.nomer ,paketan.jenis_laundry, detail_laundry.deskripsi, paketan.harga,  detail_laundry.jumlah, detail_laundry.keterangan from detail_laundry
        join pelaundry ON (pelaundry.id = detail_laundry.id_pelaundry)
        join paketan ON (paketan.id = detail_laundry.id_paketan);');
        return $this->db->resultSet();

    }
    public function getAllPaketan()
    {
        $this->db->query('SELECT * from paketan');
        return $this->db->resultSet();
    }

    public function getAllMember()
    {
        $this->db->query('SELECT * from pelaundry');
        return $this->db->resultSet();

    }
    public function ubahstatusmember($id)
        {
            $query = "UPDATE detail_laundry set keterangan = :keterangan WHERE id = :id";
            
            $this->db->query($query);
            $this->db->bind('id', $id);
            $this->db->bind('keterangan', 'selesai');
            $this->db->execute();

            return $this->db->rowCount();

        }
    public function ubahstatuspelaundry_biasa($id)
        {
            $query = "UPDATE pelaundry_biasa set keterangan = :keterangan WHERE id = :id";
            
            $this->db->query($query);
            $this->db->bind('id', $id);
            $this->db->bind('keterangan', 'selesai');
            $this->db->execute();

            return $this->db->rowCount();

        }

}