<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>01</title>
        <link href="https://cdn.jsdelivr.net/npm/remixicon@2.5.0/fonts/remixicon.css" rel="stylesheet" />
        <link rel="stylesheet" href="/public/css/indexhome.css" />
    </head>

    <body>
        <nav class="navbar container">
            <a href="#" class="logo"> Tapasan</a>
            <input type="checkbox" id="toggler" />
            <label for="toggler"><i class="ri-menu-line"></i></label>
            <div class="menu">
                <ul class="list">
                    <li><a href="index.html">Home</a></li>
                    <li><a href="tampilpaket">About</a></li>
                    <li><a href="#">Contact</a></li>
                    <li><a href="sign_pilih">Sign</a></li>

                </ul>
            </div>
        </nav>

        <article class="blog-post">
            <div class="blog-post_img">
                <img src="/public/img/logo.png" width="500"alt="">
            </div>
            <div class="blog-post_info">
                <div class="blog-post_date">
                    <span><h1>Tapasan</h1></span>
                    <span>Harum Dan Barasih Banar Tiada Tanding dan Tiada Banding</span>
                    <span>Murah Meriah Kualitas Cucian No1 di Banjarmasin </span>
                    <span>Lakasi dan Lajui Ma Laundry di Tapasan </span>
                </div>
                <h2 class="blog-post_tittle">085834568723</h2>
                <p>Hubungi No di Atas atau Tekan Tombol di Bawah Ini</p>
                <a href="#" class="blog-post_cta">Hubungi Kami</a>
            </div>
        </article>
        <div class="about">
            <div class="box"><h1>Bagian 1</h1></div>
            <div class="box"><h1>Bagian 2</h1></div>
        </div>
        <div class="container1" >
            <article style="background-image: url('/public/img/bg.jpg');" class="card">
                <div class="card__body">
                    <h2 class="card__title" >Express1</h2>
                    <p>1 hari selesai biaya 13 ribu satu kilo
                    </p>
                </div>
            </article>
            <article style="background-image: url('/public/img/bg.jpg');" class="card">
                <div class="card__body">
                    <h2 class="card__title">Express2</h2>
                    <p>
                        2 hari selesai biaya 9 ribu satu kilo
                    </p>
                </div>
            </article>
            <article style="background-image: url('/public/img/bg.jpg');" class="card">
                <div class="card__body">
                    <h2 class="card__title">Express3</h2>
                    <p>
                        2 hari selesai biaya 9 ribu satu kilo
                    </p>
                </div>
            </article>
            <article style="background-image: url('/public/img/tas.png');" class="card">
                <div class="card__body">
                    <h2 class="card__title">TAS</h2>
                    <p>
                        2 hari selesai biaya 9 ribu satu kilo
                    </p>
                </div>
            </article>
            <article style="background-image: url('/public/img/ambal.png');" class="card">
                <div class="card__body">
                    <h2 class="card__title">KARPET</h2>
                    <p>
                        2 hari selesai biaya 9 ribu satu kilo
                    </p>
                </div>
            </article>
            <article style="background-image: url('/public/img/badcover.png');" class="card">
                <div class="card__body">
                    <h2 class="card__title">BADCOVER</h2>
                    <p>
                        2 hari selesai biaya 9 ribu satu kilo
                    </p>
                </div>
            </article>
            <article style="background-image: url('/public/img/selimut.png');" class="card">
                <div class="card__body">
                    <h2 class="card__title">SELIMUT</h2>
                    <p>
                        2 hari selesai biaya 9 ribu satu kilo
                    </p>
                </div>
            </article>
            <article style="background-image: url('/public/img/sepatu.png');" class="card">
                <div class="card__body">
                    <h2 class="card__title">SEPATU</h2>
                    <p>
                        2 hari selesai biaya 9 ribu satu kilo
                    </p>
                </div>
            </article>
        </div>
    </body>
</html>